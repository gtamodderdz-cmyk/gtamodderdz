# موقع GTA MODDER DZ — دليل النشر على GitHub Pages + Firebase

## محتوى المجلد
| الملف | الوظيفة |
|---|---|
| `index.html` | الموقع كاملاً (التصميم + الصفحات + لوحة التحكم) |
| `firebase-config.js` | إعدادات Firebase — **يجب أن تملأه أنت** |
| `logo.jpg` | شعار القناة |
| `firestore.rules` | قواعد الحماية: أنت فقط من ينشر |

---

## الجزء 1: إنشاء Firebase (قاعدة البيانات + تسجيل الدخول) — مجاني

1. ادخل إلى https://console.firebase.google.com بحساب `gtamodderdz@gmail.com`.
2. اضغط **Add project** (إنشاء مشروع)، سمّه مثلاً `gtamodderdz`، ويمكنك إيقاف Google Analytics.
3. **تسجيل الدخول:** من القائمة الجانبية **Build ← Authentication ← Get started**، ثم تبويب **Sign-in method**، اختر **Google** ← **Enable** ← اختر بريدك كـ support email ← **Save**.
4. **قاعدة البيانات:** **Build ← Firestore Database ← Create database**، اختر موقعاً قريباً (مثلاً `europe-west`)، ثم **Start in production mode**.
5. **قواعد الحماية (مهم جداً):** داخل Firestore افتح تبويب **Rules**، احذف كل ما فيه، والصق محتوى ملف `firestore.rules` كاملاً، ثم اضغط **Publish**.
6. **ربط الموقع:** اضغط ⚙️ **Project settings**، وفي أسفل الصفحة **Your apps** اضغط أيقونة الويب `</>`، سجّل التطبيق بأي اسم، ستظهر لك قطعة كود فيها `firebaseConfig = { apiKey: ... }`.
   انسخ القيم وضعها في ملف `firebase-config.js` مكان `YOUR_...`.

> ملاحظة: الـ `apiKey` ليس سراً، من الطبيعي أن يكون ظاهراً. الحماية الحقيقية هي ملف القواعد في الخطوة 5.

---

## الجزء 2: النشر على GitHub Pages — مجاني

1. أنشئ حساباً على https://github.com إن لم يكن لديك.
2. اضغط **+ ← New repository**، سمّه `gtamodderdz`، اختر **Public**، ثم **Create repository**.
3. اضغط **uploading an existing file** (أو **Add file ← Upload files**)، واسحب الملفات: `index.html` و`firebase-config.js` (بعد ملئه) و`logo.jpg`، ثم **Commit changes**.
4. ادخل **Settings ← Pages**، وفي **Source** اختر **Deploy from a branch**، الفرع `main` والمجلد `/ (root)` ← **Save**.
5. بعد دقيقة أو دقيقتين سيظهر رابط موقعك:
   `https://اسم-حسابك.github.io/gtamodderdz/`

### خطوة أخيرة ضرورية
ارجع إلى Firebase: **Authentication ← Settings ← Authorized domains ← Add domain** وأضف:
`اسم-حسابك.github.io`
بدونها لن يعمل زر تسجيل الدخول على موقعك.

---

## الجزء 3: الاستخدام

- افتح موقعك واضغط **تسجيل الدخول** بحساب `gtamodderdz@gmail.com` ← سيظهر لك زر **لوحة التحكم**.
- من لوحة التحكم: رفع مود (صور + تفاصيل + رابط تحميل)، تعديل/حذف، نشر أخبار، إضافة فيديوهات.
- الزوار: يتصفحون ويحمّلون بدون حساب، ويسجلون الدخول بـ Google للإعجاب والتعليق.
- تستطيع حذف أي تعليق مزعج من صفحة المود.

### من يستطيع النشر؟
**أنت فقط.** القواعد في Firebase ترفض أي محاولة كتابة للمودات/الأخبار/الفيديوهات/الصور من أي حساب غير `gtamodderdz@gmail.com` — حتى لو عدّل أحدهم كود الموقع أو نسخه.
لتغيير بريد الأدمن: غيّره في `firebase-config.js` **وفي** `firestore.rules` ثم أعد نشر القواعد.

---

## ملاحظات
- **ملفات المودات:** ارفعها على MediaFire / Google Drive / Mega وضع الرابط في خانة "رابط التحميل".
- **الصور:** تُضغط تلقائياً وتُحفظ في Firestore (لا تحتاج خطة مدفوعة).
- **الخطة المجانية (Spark):** حوالي 50,000 قراءة يومياً — تكفي جيداً للبداية. إن كبر الموقع جداً يمكن الترقية لاحقاً.
- **لا تفتح `index.html` مباشرة من جهازك** (بالنقر المزدوج) — لن يعمل بسبب قيود المتصفح. جرّبه على رابط GitHub Pages.
- **تعديل الموقع لاحقاً:** في GitHub افتح الملف ← أيقونة القلم ✏️ ← عدّل ← Commit. يتحدث الموقع خلال دقيقة.
- **دومين خاص (اختياري):** اشترِ مثلاً `gtamodderdz.com` وأضفه في **Settings ← Pages ← Custom domain**، ثم أضفه أيضاً في Authorized domains في Firebase.
