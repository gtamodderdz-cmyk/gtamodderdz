// ضع هنا إعدادات مشروعك من Firebase (Project settings > Your apps > Web app > SDK setup and configuration)
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// البريد الوحيد المسموح له بالنشر (لوحة التحكم)
export const ADMIN_EMAIL = "gtamodderdz@gmail.com";
